package OregonTrail;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author Caramel Corn
 * @since 3/31/2020
 * @version 1.0
 */
public class Item {
    private double weight;
    private String name;
    private boolean carried;
    private int quantity;
    private boolean isFood;
    private double cumulativeWeight;
    
    /**
     * A constructor to create each item for the player's inventory
     * @param weight - how much each item weighs
     * @param name - the identifier for the player to know what everything is
     * @param isFood - a check for if the item is considered food
     */
    public Item(double weight,String name,boolean isFood)
    {
        this.isFood = isFood;
        this.name = name;
        this.weight = weight;
        this.carried = false;
        this.quantity = 1;
        this.cumulativeWeight = 0;
    }
    
    /**
     * returns the combined weight of the items
     * @return a double total weight of the items the player has
     */
    public double getCumulativeWeight()
    {
        return cumulativeWeight;
    }
    
    /**
     * increases the cumulative weight of the player's inventory
     * @param weight - the weight of the item being added to the total
     */
    public void addWeight(double weight)
    {
        this.cumulativeWeight += weight;
    }
   
    /**
     * a function to see if the item is edible
     * @return if the item is considered food
     */
    public boolean isFood()
    {
        return isFood;
    }
    
    /**
     * decreases the amount of an item in the player's inventory
     */
    public void decreaseQuantity()
    {
        this.quantity--;
    }
    
    /**
     * determines the amount of each item in the player's inventory
     * @param quantity the chosen amount of the item
     */
    public void setQuantity(int quantity)
    {
        this.quantity = quantity;
    }
    
    /**
     * a function to determine how much of an item is present in the inventory
     * @return an integer amount of an item 
     */
    public int getQuantity()
    {
        return quantity;
    }
    
    /**
     * increase the amount of the item by 1
     */
    public void addItem()
    {
        this.quantity += 1;
    }
    
    /**
     * a function to see if the item is in the player's inventory
     * @return true or false for if the item is present
     */
    public boolean isCarried()
    {
        return carried;
    }
    
    /**
     * a function to return the name associated with the item
     * @return the identifier of the item
     */
    public String getName()
    {
        return this.name;
    }
    
    /**
     * a function to set the weight for a particular item
     * @param weight a double value for the weight, in pounds, of an object
     */
    public void setWeight(double weight)
    {
        this.weight = weight;
    }
    
    /**
     * a function to return the weight of a certain item
     * @return the double value, in pounds, of an item
     */
    public double getWeight()
    {
        return this.weight;
    }
    
    /**
     * sets an item as carried and sets it's quantity to one
     */
    public void carry()
    {
        this.carried = true;
        this.quantity = 1;
    }
    
    /**
     * a function that formats the output of an item's name and weight to be uniform upon output after it is being carried
     * @return a string containing the item's name and weight in a uniform manner
     */
    public String toStringAfterCarry()
    {
        String output = "";
        for(int i = 0; i < quantity; i++)
        {
            String oneItem;
            oneItem = "  " + weight;
            while(oneItem.length() < 12)
            {
                oneItem += " ";
            }
            oneItem += name;
            output += oneItem + "\n";
        }
        return output;
    }
    
    /**
     * a function that formats the output of an item's name and weight to be uniform upon output
     * @return a string containing the item's name and weight in a uniform manner
     */
    public String toString()
    {
        String output = "" + weight;
        while(output.length() < 10)
        {
            output += " ";
        }
        output += name + "\n";
        return output;       
    }
}
